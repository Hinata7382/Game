-- main.lua
local clicks = 0
local money = 0
local rebirths = 0
local click_value = 1
local money_bonus = 0
local click_interval = 0.5
local last_click_time = -click_interval
local show_menu = false
local show_rebirth_menu = false
local show_second_market = false

-- Ekran boyutlarını ayarla
local screen_width = 2460
local screen_height = 1940

-- Menü buton koordinatları
local menu_button = { x = 10, y = 10, width = 100, height = 40 }
local rebirth_button = { x = 120, y = 10, width = 100, height = 40 }
local second_market_button = { x = 230, y = 10, width = 120, height = 40 }

-- Menü içeriği kaydırma için değişkenler
local menu_scroll_y = 0
local menu_scroll_speed = 10
local touch_start_y = 0
local dragging_menu = false
local menu_max_scroll_y = 0

-- Market özellikleri
local features = {
    { name = "Double Clicks", cost = 10, effect = function() click_value = click_value * 2 end, purchased = false },
    { name = "Extra Money", cost = 200, effect = function() money_bonus = money_bonus + 1 end, purchased = false },
    { name = "Faster Clicks", cost = 1000, effect = function() click_interval = click_interval * 0.9 end, purchased = false },
    { name = "Triple Clicks", cost = 10000, effect = function() click_value = click_value * 3 end, purchased = false },
    { name = "Quadruple Clicks", cost = 50000, effect = function() click_value = click_value * 4 end, purchased = false },
    { name = "Click Frenzy", cost = 100000, effect = function() click_value = click_value * 5 end, purchased = false },
    { name = "Money Rain", cost = 120000, effect = function() money_bonus = money_bonus + 5 end, purchased = false },
    { name = "Click Multiplier", cost = 150000, effect = function() click_value = click_value * 6 end, purchased = false },
    { name = "Money Multiplier", cost = 200000, effect = function() money_bonus = money_bonus + 10 end, purchased = false },
    { name = "Auto Clicker", cost = 300000, effect = function() click_interval = click_interval * 0.7 end, purchased = false },
    { name = "Double Money", cost = 400000, effect = function() money_bonus = money_bonus + 15 end, purchased = false }
}

-- İkinci market özellikleri
local second_market_features = {
    { name = "Super Clicks - Purchase with Money", cost = 100, effect = function() click_value = click_value * 2 end, purchased = false },
    { name = "Mega Money - Purchase with Money", cost = 300, effect = function() money_bonus = money_bonus + 3 end, purchased = false },
    { name = "Ultra Clicks - Purchase with Money", cost = 1000, effect = function() click_value = click_value * 3 end, purchased = false },
    { name = "Extreme Clicks - Purchase with Money", cost = 10000, effect = function() click_value = click_value * 4 end, purchased = false },
    { name = "Hyper Money - Purchase with Money", cost = 50000, effect = function() money_bonus = money_bonus + 7 end, purchased = false },
    { name = "Mega Clicks - Purchase with Money", cost = 100000, effect = function() click_value = click_value * 5 end, purchased = false },
    { name = "Ultimate Money - Purchase with Money", cost = 130000, effect = function() money_bonus = money_bonus + 10 end, purchased = false }
}

-- Fonksiyonlar
function love.load()
    love.window.setTitle("Clicker Simulator")
    love.window.setMode(screen_width, screen_height)
    font = love.graphics.newFont(14)
    love.graphics.setFont(font)

    -- Menü içeriği kaydırma sınırı hesaplama
    local num_features = #features
    local num_second_market_features = #second_market_features
    local feature_height = 20
    menu_max_scroll_y = math.max(num_features * feature_height, num_second_market_features * feature_height)

    -- İlerlemeyi yükle
    loadProgress()
end

function love.draw()
    love.graphics.printf("Clicks: " .. clicks, 0, 20, love.graphics.getWidth(), "center")
    love.graphics.printf("Money: " .. money, 0, 40, love.graphics.getWidth(), "center")
    love.graphics.printf("Rebirths: " .. rebirths, 0, 60, love.graphics.getWidth(), "center")

    -- Menü butonu
    love.graphics.setColor(0.7, 0.7, 0.7)
    love.graphics.rectangle("fill", menu_button.x, menu_button.y, menu_button.width, menu_button.height)
    love.graphics.setColor(1, 1, 1)
    love.graphics.printf("Menu", menu_button.x, menu_button.y + 10, menu_button.width, "center")

    -- Rebirth butonu
    love.graphics.setColor(0.7, 0.7, 0.7)
    love.graphics.rectangle("fill", rebirth_button.x, rebirth_button.y, rebirth_button.width, rebirth_button.height)
    love.graphics.setColor(1, 1, 1)
    love.graphics.printf("Rebirth", rebirth_button.x, rebirth_button.y + 10, rebirth_button.width, "center")

    -- İkinci Market butonu
    love.graphics.setColor(0.7, 0.7, 0.7)
    love.graphics.rectangle("fill", second_market_button.x, second_market_button.y, second_market_button.width, second_market_button.height)
    love.graphics.setColor(1, 1, 1)
    love.graphics.printf("Second Market", second_market_button.x, second_market_button.y + 10, second_market_button.width, "center")

    if show_menu then
        love.graphics.setColor(0.2, 0.2, 0.2, 0.9)
        love.graphics.rectangle("fill", 50, 50, screen_width - 100, screen_height - 100)
        love.graphics.setColor(1, 1, 1)
        love.graphics.printf("Market Features", 50, 60, screen_width - 100, "center")

        for i, feature in ipairs(features) do
            local feature_text = feature.name .. " - Cost: " .. feature.cost
            if feature.purchased then
                feature_text = feature_text .. " (Purchased)"
            end
            love.graphics.printf(feature_text, 60, 80 + (i - 1) * 20 - menu_scroll_y, screen_width - 120, "left")
        end
    end

    if show_rebirth_menu then
        love.graphics.setColor(0.2, 0.2, 0.2, 0.9)
        love.graphics.rectangle("fill", 50, 50, screen_width - 100, screen_height - 100)
        love.graphics.setColor(1, 1, 1)
        love.graphics.printf("Rebirth Menu", 50, 60, screen_width - 100, "center")
        love.graphics.printf("Clicks: " .. clicks .. "/10000", 60, 90, screen_width - 120, "left")
        love.graphics.printf("Money: " .. money .. "/5000", 60, 110, screen_width - 120, "left")
        love.graphics.printf("Rebirth to reset clicks and money for bonuses", 60, 140, screen_width - 120, "left")
    end

    if show_second_market then
        love.graphics.setColor(0.2, 0.2, 0.2, 0.9)
        love.graphics.rectangle("fill", 50, 50, screen_width - 100, screen_height - 100)
        love.graphics.setColor(1, 1, 1)
        love.graphics.printf("Second Market Features", 50, 60, screen_width - 100, "center")

        for i, feature in ipairs(second_market_features) do
            local feature_text = feature.name .. " - Cost: " .. feature.cost
            if feature.purchased then
                feature_text = feature_text .. " (Purchased)"
            end
            love.graphics.printf(feature_text, 60, 80 + (i - 1) * 20 - menu_scroll_y, screen_width - 120, "left")
        end
    end
end

function love.mousepressed(x, y, button_pressed, istouch, presses)
    if button_pressed == 1 then
        local current_time = love.timer.getTime()
        if current_time - last_click_time >= click_interval then
            clicks = clicks + click_value
            money = money + click_value + money_bonus
            last_click_time = current_time
        end

        -- Menü butonuna tıklama
        if x > menu_button.x and x < menu_button.x + menu_button.width and
           y > menu_button.y and y < menu_button.y + menu_button.height then
            show_menu = not show_menu
            show_rebirth_menu = false
            show_second_market = false
            -- Menüye girerken kaydırma konumunu sıfırla
            menu_scroll_y = 0
        end

        -- Rebirth butonuna tıklama
        if x > rebirth_button.x and x < rebirth_button.x + rebirth_button.width and
           y > rebirth_button.y and y < rebirth_button.y + rebirth_button.height then
            show_rebirth_menu = not show_rebirth_menu
            show_menu = false
            show_second_market = false
        end

        -- İkinci Market butonuna tıklama
        if x > second_market_button.x and x < second_market_button.x + second_market_button.width and
           y > second_market_button.y and y < second_market_button.y + second_market_button.height then
            show_second_market = not show_second_market
            show_menu = false
            show_rebirth_menu = false
        end

        -- Özelliklere tıklama
        if show_menu then
            for i, feature in ipairs(features) do
                if x > 60 and x < screen_width - 60 and y > 80 + (i - 1) * 20 - menu_scroll_y and y < 100 + (i - 1) * 20 - menu_scroll_y then
                    if not feature.purchased and clicks >= feature.cost then
                        clicks = clicks - feature.cost
                        feature.purchased = true
                        feature.effect()
                        saveProgress() -- İlerlemeyi kaydet
                    end
                end
            end
        end

        -- İkinci Market özelliklerine tıklama
        if show_second_market then
            for i, feature in ipairs(second_market_features) do
                if x > 60 and x < screen_width - 60 and y > 80 + (i - 1) * 20 - menu_scroll_y and y < 100 + (i - 1) * 20 - menu_scroll_y then
                    if not feature.purchased and money >= feature.cost then
                        money = money - feature.cost
                        feature.purchased = true
                        feature.effect()
                        saveProgress() -- İlerlemeyi kaydet
                    end
                end
            end
        end

        -- Rebirth işlemi
        if show_rebirth_menu then
            if clicks >= 10000 and money >= 5000 then
                clicks = 0
                money = 0
                rebirths = rebirths + 1
                click_value = click_value + 1 -- Rebirth bonus
                show_rebirth_menu = false
                saveProgress() -- İlerlemeyi kaydet
            end
        end
    end
end

function love.touchpressed(id, x, y, dx, dy, pressure)
    touch_start_y = y
    dragging_menu = true
end

function love.touchmoved(id, x, y, dx, dy, pressure)
    if dragging_menu then
        menu_scroll_y = math.max(0, math.min(menu_scroll_y - dy * menu_scroll_speed, menu_max_scroll_y))
    end
end

function love.touchreleased(id, x, y, dx, dy, pressure)
    dragging_menu = false
end

function love.mousemoved(x, y, dx, dy, istouch)
    if istouch then return end
    if dragging_menu then
        menu_scroll_y = math.max(0, math.min(menu_scroll_y - dy * menu_scroll_speed, menu_max_scroll_y))
    end
end

-- İlerlemeyi kaydet
function saveProgress()
    local data = {
        clicks = clicks,
        money = money,
        rebirths = rebirths,
        click_value = click_value,
        money_bonus = money_bonus
    }
    love.filesystem.write("progress.dat", serialize(data))
end

-- İlerlemeyi yükle
function loadProgress()
    if love.filesystem.getInfo("progress.dat") then
        local data = deserialize(love.filesystem.read("progress.dat"))
        clicks = data.clicks
        money = data.money
        rebirths = data.rebirths
        click_value = data.click_value
        money_bonus = data.money_bonus
    end
end

-- Basit bir serileştirme fonksiyonu
function serialize(data)
    local serialized = ""
    for key, value in pairs(data) do
        serialized = serialized .. key .. "=" .. tostring(value) .. "\n"
    end
    return serialized
end

-- Basit bir serileştirme çözme fonksiyonu
function deserialize(serialized)
    local data = {}
    for line in serialized:gmatch("[^\r\n]+") do
        local key, value = line:match("([^=]+)=([^=]+)")
        if key and value then
            data[key] = tonumber(value) or value
        end
    end
    return data
end
